osn_serv=20 # от
osn_lim=30 # До

start_json=20  # от
lim_json=30 # До