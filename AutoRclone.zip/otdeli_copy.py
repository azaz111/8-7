from google.oauth2 import service_account
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
import io
from googleapiclient.errors import HttpError
import os
from sys import argv
import json
from collections import Counter
from itertools import chain
from BIB_API import service_avtoriz , spisok_fails_roditelya , drive_ls
successful=[]
def _is_success0(id, resp, exception):
    global successful
    if exception is None:
        successful.append(resp['id'])

fold = '1dl33gWNIVoVsZxTk5dcSWiW4sCZQ7CqN' # Большая папка 
ttt = '1vyix04eOuYPQdoB41wLm_nIscormaHDk'  # разница

service = service_avtoriz()
service2 = service_avtoriz('v2')

if len(drive_ls(service)) == 1 :
   s_iddrive=drive_ls(service)[0]['id']

else:
   print( 'НЕ пойму какого хрена вижу больше одного диска ') 
   exit()


q=0

lenss1=spisok_fails_roditelya(fold,s_iddrive,service) # Список всех файлов
int_list=[eee.get('name') for eee in lenss1 ] # Список всех Имен файлов
new_list = list(set(int_list))# Список уникальных имен
print(len(new_list))

final_list_counts = Counter(int_list) - Counter(new_list)
final_list = list(chain(*[[t] * count for t, count in final_list_counts.items()]))
print(final_list) # Список имен копий 


#print(lenss1)
#obschie=obschie+lenss
print('naideno copy : '+str(len(final_list)))
print('----------------------------------------')
input('Перенести ? ')
file_ids=[]

for i in lenss1:
    spp0=i.get('name')
    if spp0 in final_list:
        file_ids.append(i)  # Список с 2 копийями
        #with open(f'dd.csv', 'a') as fq:
        #    fq.write(str(i)+'\n')
nd=[]
unique = []
dibles = []

for item in file_ids: 
    #print(item)
    if item['name'] not in unique:
        nd.append(item)      # Уникальные 
        unique.append(item['name']) 
    else:
        dibles.append(item) # Не Уникальных

print(str(len(nd)) + '- Уникальных')
print(str(len(dibles)) + '- Не Уникальных')



ls_files=[eee.get('id') for eee in dibles ]
while True :
    ls_files=list(set(ls_files)-set(successful))
    batch = service.new_batch_http_request(callback=_is_success0) 
    for i in ls_files[:500]:
        batch.add(service.files().update(fileId=i,
                                addParents=ttt,
                                supportsAllDrives=True, 
                                removeParents=fold, fields='id, parents'))
    print('Otpravka zaprosa')
    batch.execute()
    if len(ls_files) == 0:
        successful=[]
        print('Konec')
        break